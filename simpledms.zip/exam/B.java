package com.simplecoding.simpledms.exam;

public class B {
//    2번 문제 풀이: 틀린것 완성하기
}
