package com.simplecoding.simpledms.exam;

public class A {
//    1번 문제 풀이: 이론
}
